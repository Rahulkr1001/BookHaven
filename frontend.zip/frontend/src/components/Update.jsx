import React from 'react'



const Update = () => {
  return (
    <>
   <div className="mockup-window bg-base-300 border">
  <div className="bg-base-200 flex justify-center px-4 py-16">Soon We Will Add book</div>
  <button className=" cursor-pointer px-2 py-1 rounded-full border-[2px] hover:bg-pink-500 hover:text-white duration-200"><a href="/">Back to Home Page</a></button>
    </div>
    </>
  )
}

export default Update
